Project criteria met:
	We have fulfilled all the required criteria and were successful in creating each of t1-t5 files. 
	We did not add additional features for lack of time due to the midterm.

Work Split:
	To split the work we started on opposite ends of the project and met in the middle. We created a remote git repo to collaborate and used Facebook Messenger to communicate.

		Tremaine: search.php, addActorOrDirector.php, addMovie.php, index.php, and handled the Selenium testing. Also brought together the relevant Bootstrap/CSS styling to create a decent looking UI.
			(I1, I2, t1, t2, t3, t4, t5)

		Mitchell: addComments.php, addDirectorToMovie.php, addActorToMovie.php, showActorInfo.php, showMovieInfo.php
			(I3, I4, I5, B1, B2)

Improve collaboration:
	To improve our level of collaboration we should communicate more to see if the other is struggling, behind, or needs help. Doing so would have allowed us to implement additional features.
