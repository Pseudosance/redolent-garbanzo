Tremaine Eto tremaineeto@ucla.edu
Mitchell Binning mitchellbinning@ucla.edu

This is the Part A submission, where only SqlEngine.cc has been modified and implemented according to the spec.
